import React from 'react'

const Features = () => {
  return (
    <>
        <div className='parent' id='features'>
            <div className='image'>
                <img src="/images/image 2.svg" alt="" width="550px" height="450px" />
            </div>
            <div className='information'> 
                <h1>We Provide Many <br />
                 Features You Can Use</h1>
                 <p>You can explore the features that we provide with fun and <br />
                  have their own functions each feature.</p>
                  <p><img src="/images/tickmark.svg" width="25px" height="25px" alt="" /> Powerfull online protection.</p>
                  <p><img src="/images/tickmark.svg" width="25px" height="25px" alt="" /> Internet without borders.</p>
                  <p><img src="/images/tickmark.svg" width="25px" height="25px" alt="" /> Supercharged VPN</p>
                  <p><img src="/images/tickmark.svg" width="25px" height="25px" alt="" /> No specific time limits.</p>
            </div>
        </div>
    </>
  )
}

export default Features