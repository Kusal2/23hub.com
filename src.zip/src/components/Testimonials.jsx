import React from 'react'

const Testimonials = () => {
  return (
    <div className='testimonials' id='testimonials'>
        <div className='trust'>
            <div>
                <h1>Trusted by Thousands of Happy <br /> Customer</h1><br />
                <p>These are the stories of our customers who have joined us with great <br /> <br /> pleasure when using this crazy feature.</p>
            </div>
        </div>
        <div className='comments'>
            <div className='coment'>
                <div><img src="/images/Ellipse 175.png" alt=""  width="50px" height="50px"/>
                  <span><b>Veiz Robert</b><br />Varswa, Poland</span>
                </div><br />
                <div>
                    <p>"Wow... I am very happy to use this VPN, in
                    turned out to be more than expectations 
                    and so far and there have been no problems.
                    LaslesVPN always is the best" </p>
                </div>
            </div>
            <div className='coment'>
                <div><img src="/images/Ellipse 175 (1).png" width="50px" height="50px"/>
                  <span><b>Yessica Christy</b><br />Shanxi, Chaina</span>
                </div><br />
                <div>
                    <p>"I like it because i like to travel far and 
                      still can connect with high speed." </p>
                </div>
            </div>
            <div className='coment'>
                <div><img src="/images/Ellipse 175 (2).png" width="50px" height="50px"/>
                  <span><b>Kim Young Jou</b><br />Seoul, South Korea</span>
                </div><br />
                <div>
                    <p>"This is very unusual for my bussiness that
                      currently requires a virtual private network 
                      that has high security." </p>
                </div>
            </div>
        </div>
    </div>
  )
}

export default Testimonials