import React from 'react'

const Home = () => {
  return (
    <>
      <div className='first'>
        <div className='want'>
            <h1>Want anything to be easy with LaslesVPN.</h1>
            <p>Provide a network for all your needs with ease and fun using <b>LaslesVPN</b> <br />
            discover interesting features from us.</p>
            <button className='get'>Get Started</button>
        </div>
        <div className='pic1'>
            <img src="/images/pic1.svg" alt="" width="550px" height="450px" />
        </div>
      </div>
    </>
  )
}

export default Home