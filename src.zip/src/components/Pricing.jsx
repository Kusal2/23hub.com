import React from 'react'

const Pricing = () => {
  return (
    <>
        <div className='chooseplan' id='pricing'>
                <div className='yourplan'>
                    <h1>Choose Your Plan</h1><br />
                    <p>Let's choose the package that is best for you and explore it happily and <br /> cheerfully.</p>
                </div>
        </div>
            <div className='chooseplan1'>
                <div className='bord'>
                    <div className='plans'>
                        <img src="/images/giftbox.svg" width="150px" height="170px" alt="" /><br /><br />
                        <h3>Free Plan</h3>
                    </div>
                    <div className='plans1'>
                        <ul>
                            <li>Unlimited Bandwitch</li>
                            <li>Encrypted Connection</li>
                            <li>No Traffic Logs</li>
                            <li>Works on All Devices</li>
                        </ul>
                        <h1 className='monthly'>Free</h1>
                        <button className='select'>Select</button>
                    </div>
                </div>
                <div className='bord'>
                    <div className='plans'>
                        <img src="/images/giftbox.svg" width="150px" height="170px" alt="" /><br /><br />
                        <h3>Standard Plan</h3>
                    </div>
                    <div className='plans1'>
                        <ul>
                            <li>Unlimited Bandwitch</li>
                            <li>Encrypted Connection</li>
                            <li>Yes Traffic Logs</li>
                            <li>Works on All Devices</li>
                            <li>Connect Anywhere</li>
                        </ul>
                        <h1 className='monthly1'>$9<span className='span'> / mo</span></h1>
                        <button className='select'>Select</button>
                    </div>
                </div>
                <div className='bord'>
                    <div className='plans'>
                        <img src="/images/giftbox.svg" width="150px" height="170px" alt="" /><br /><br />
                        <h3>Free Plan</h3>
                    </div>
                    <div className='plans1'> 
                        <ul>
                            <li>Unlimited Bandwitch</li>
                            <li>Encrypted Connection</li>
                            <li>Yes Traffic Logs</li>
                            <li>Works on All Devices</li>
                            <li>Connect Anywhere</li>
                            <li>Get New Features</li>
                        </ul>
                        <h1 className='monthly2'>$12<span className='span'> / mo</span></h1>
                        <button className='select'>Select</button>
                    </div>
                </div>
            </div>
    </>
  )
}

export default Pricing