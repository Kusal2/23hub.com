import React from 'react'

const Locations = () => {
  return (
    <>
        <div className='global'>
            <div className='global1'>
                <h1>Huge Global Network <br /> of Fast VPN</h1><br />
                <p>See LaslesVPN everywhere to make it easier for you when you move <br /> locations.</p>
            </div>
            <div className='map'>
                <img src="/images/map.svg" width="1300px" height="550px" alt="" />
            </div>
        </div>
        <div className='ott'>
            <div className='image3'><img src="/images/netflix.svg" width="200px" height="100px" alt="" /></div>
            <div className='image3'><img src="/images/reddit.svg" width="200px" height="100px" alt="" /></div>
            <div className='image3'><img src="/images/amazon.svg" width="200px" height="100px" alt="" /></div>
            <div className='image3'><img src="/images/discord.svg" width="200px" height="100px" alt="" /></div>
            <div className='image3'><img src="/images/spotify.svg" width="200px" height="100px" alt="" /></div>
        </div>
    </>
  )
}

export default Locations