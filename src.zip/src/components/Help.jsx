import React from 'react'

const Help = () => {
  return (
    <>
        <div id='help'>
            <div className='subscribe'>
                <div>
                    <h1>Subscribe Now for <br /> Get Special Features!</h1>
                    <p>Let's subscribe with us and find the fun.</p>
                </div><br />
                        <button className='subscribenow'>Subscibe Now</button>
            </div>
        </div>
        <div className='last'>
            <div className='logo'>
              <div>
                    <img src="/images/Logo.svg" width="150px" alt="" /><br /><br />
                    <p className='para'>LaslesVPN is a private virtual network that <br /> 
                        has unique features and has high security.</p>
                    <div className='icons'>
                        <img className='icon' src="/images/Facebook.svg" alt="" width="20px" height="20px" />
                        <img className='icon' src="/images/Twitter.svg" alt="" width="20px" height="20px" />
                        <img className='icon' src="/images/Instagram.svg" alt="" width="20px" height="20px" />
                    </div>
                <p>© 2020 LaslesVPN</p>
              </div>
              <div className="lastcontents">
                <div className='two'>
                    <h3>Product</h3>
                    <a href="" className='align'>Download</a><br />
                    <a href="" className='align'>Pricing</a><br />
                    <a href="" className='align'>Locations</a><br />
                    <a href="" className='align'>Server</a><br />
                    <a href="" className='align'>Countries</a><br />
                    <a href="" className='align'>Blog</a><br />
                </div>
                <div className='two'>
                    <h3>Engage</h3>
                    <a href="" className='align'>LaslesVPN</a><br />
                    <a href="" className='align'>FAQ</a><br />
                    <a href="" className='align'>Tutorials</a><br />
                    <a href="" className='align'>Abou Us</a><br />
                    <a href="" className='align'>Privacy Policy</a><br />
                    <a href="" className='align'>Terms of Service</a><br />
                </div>
                <div className='two'>
                    <h3>Earn Money</h3>
                    <a href="" className='align'>Affiliate</a><br />
                    <a href="" className='align'>Become Partner</a>
                </div>
              </div>
            </div>
        </div>
    </>
  )
}

export default Help