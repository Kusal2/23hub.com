import React from 'react'


const About = () => {
  return (
    <>
      <div className='location' id='about'>
            <div className='boxes'>
              <div className='loc'><img src="/images/contact.svg" alt="" width="30px" height="20px"/></div>30+</div>
            <div className='boxes1'>
              <div className='loc'>
                <img src="/images/location.svg" alt="" width="30px" height="30px"/></div>50+</div>
            <div className='boxes2'>
              <div className='loc'>
                <img src="/images/doubledot.svg" alt="" width="30px" height="30px"/></div>90+</div>
      </div>
    </>
  )
}

export default About