import React from 'react'
import {Routes , Route } from 'react-router-dom'
import Navbar from './Navbar/Navbar'
import Home from './components/Home'
import About from './components/About'
import Features from './components/Features'
import Pricing from './components/Pricing'
import Testimonials from './components/Testimonials'
import Help from './components/Help'
import Locations from './components/Locations'




const App = () => {
  return (
    <>
        <Navbar />
        <Routes>
            <Route path='about'>  </Route>
            <Route path='features'></Route>
            <Route path='pricing'></Route>
            <Route path='testimonials'></Route>
            <Route path='help'></Route>
            <Route path='loca'></Route>
        </Routes> 
        <Home />
        <About />
        <Features />
        <Pricing />
        <Locations />
        <Testimonials />
        <Help />
    </>
  )
}

export default App