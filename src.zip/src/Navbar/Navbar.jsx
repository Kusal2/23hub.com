import React from 'react'
import { NavLink } from 'react-router-dom'

const Navbar = () => {
  return (
    <>
        <div className='navbar'>
            <div className='home' ><img src="/images/Logo.svg" alt="" width="150px" /></div>
            <a className='about' href="#about">About</a>
            <a className='nav-link' href="#features">Features</a>
            <a className='nav-link' href="#pricing">Pricing</a>
            <a className='nav-link' href="#testimonials">Testimonials</a>
            <a className='nav-link' href="#help">Help</a>
            <button className='signin'>Sign In</button>
            <button className='signup'>Sign Up</button>
        </div>
    </>
  )
}

export default Navbar